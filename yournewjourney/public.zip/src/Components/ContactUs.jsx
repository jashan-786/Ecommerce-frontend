import React from 'react'
import { Text } from '@chakra-ui/react'

export default function ContactUs() {
  return (
    <div>
        <Text fontSize="3xl" >ContactUs </Text>
        
        515 Portage Ave, Winnipeg, MB R3B 2E9<br/>
                <a href="mailto:yournewjourneyinfo@gmail.com">yournewjourneyinfo@gmail.com</a><br/>
                123-456-7890


        <div>
            
        <Text fontSize={"3xl"}> Office Hours</Text>
        <p>
            Monday - Friday<br/> 9:00am - 8:00pm
        </p>
        <p>
            Saturday and Sunday<br/> 10:00am - 5:00pm
        </p>

        </div>
        
        </div>

  )
}