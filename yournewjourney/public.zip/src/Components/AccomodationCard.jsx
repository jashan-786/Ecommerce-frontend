import React, { useEffect } from 'react'
import { Card, Stack, CardHeader, CardBody, CardFooter, Heading, Image, Text, Center, Divider, ButtonGroup, Button, Box, Badge } from '@chakra-ui/react'
import { useNavigate } from 'react-router-dom'
import { useRecoilState } from 'recoil';
import { cartState, currentItem } from './StateManage';

export default function AccomodationCard(props) {

  const [cart, setCart] = useRecoilState(cartState);
  const [item, setItem] = useRecoilState(currentItem)


  const handleAddToCart = () => {

    const newItem = { id: props.id, name: props.name, price: props.price, img: props.img, desc: props.desc , condition: props.condition };
    setCart([...cart, newItem]);
    setItem([{ info: props.fullInfo }])


  };
  useEffect(() => {
    console.log('Cart updated:', cart);
  }, [cart]); // Trigger the effect when cart changes

  let navigate = useNavigate()
  return (

    <Box onClick={() => { setItem([{ info: props.fullInfo }]); navigate('/accomodation/moreinfo') }} style={{ width: '300px', height: '400px' }} borderWidth='1px' borderRadius='lg' overflow='hidden'>
      <Image src={props.img}
        height={200}
        width={300}

        //             alt='Green double couch with wooden legs'
        borderRadius='lg' />

      <Box p='6'>
        <Box display='flex' alignItems='baseline'>
          <Badge borderRadius='full' px='2' colorScheme='teal'>
            New
          </Badge>
          <Box
            color='gray.500'
            fontWeight='semibold'
            letterSpacing='wide'
            fontSize='xs'
            textTransform='uppercase'
            ml='2'
          >
            baths
          </Box>
        </Box>

        <Box
          mt='1'
          fontWeight='semibold'
          as='h4'
          lineHeight='tight'
          noOfLines={1}
        >
          {props.name}
        </Box>

        <Box>
          ${props.price}
          <Box as='span' color='gray.600' fontSize='sm'>

          </Box>
        </Box>
        <Box>
          <Button variant='ghost' mt={10} backgroundColor="gray.300" onClick={(e) => {
             e.stopPropagation();

            handleAddToCart();
            console.log(cart); alert("item added")
          }} >
            Add to cart
          </Button>


        </Box>


      </Box>
    </Box>
  )
}


