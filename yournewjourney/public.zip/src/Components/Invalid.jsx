import React from 'react'

export default function Invalid() {
  return (
    <div> Invalid Route</div>
  )
}
