import React from 'react'

export default function AirportPickup() {
  return (
    <div>AirportPickup</div>
  )
}
