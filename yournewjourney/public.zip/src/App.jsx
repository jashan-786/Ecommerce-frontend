
import './App.css'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';


import { ChakraProvider } from '@chakra-ui/react'
import AboutUs from './Components/AboutUs'
import Navigation from './Components/Navigation';
import Services from './Components/Services';
import Resume from './Components/Resume';
import ContactUs from './Components/ContactUs';
import Home from './Components/Home';
import Appointment from './Components/Appointment';
// import Login from './Components/Login';
import Accomodation from './Components/Accomodation';
import { RecoilRoot, useRecoilValue } from 'recoil';
import Cart from './Components/Cart';
import { currentItem } from './Components/StateManage';
import FurnitureService from './Components/FurnitureService';
import AccomodationInfo from './Components/AccomodationInfo';
import AirportPickup from './Components/AirportPickup';


import { ClerkProvider } from "@clerk/clerk-react";
import Signin from './Components/SignIn';
import Singnup from './Components/Singnup';
import Invalid from './Components/Invalid';
// if (!process.env.REACT_APP_CLERK_PUBLISHABLE_KEY) {
//   throw new Error("Missing Publishable Key")
// }
// REACT_APP_CLERK_PUBLISHABLE_KEY=pk_test_ZWxlY3RyaWMtb3gtNzAuY2xlcmsuYWNjb3VudHMuZGV2JA

const clerkPubKey = "pk_test_ZWxlY3RyaWMtb3gtNzAuY2xlcmsuYWNjb3VudHMuZGV2JA"


function App() {

  const totalCartItems = useRecoilValue(currentItem);
  return (
    <ClerkProvider  publishableKey={clerkPubKey}>
    <ChakraProvider>
    
      <Router>
        <Navigation/>
        <Routes>
          <Route path='/About' Component={AboutUs} />
          <Route path='/Services' Component={Services} />
          <Route path='/Resume' Component={Resume} />
          <Route  path='/ContactUs' Component={ContactUs}/>
          <Route path='/Home' Component={Home}/>
          <Route path= "/Appointment"  Component={Appointment}/>
          <Route path="/SignIn" Component={Signin}/>
          <Route path="/SignUp" Component={Singnup}/>
          
          <Route path="/Accomodation" Component={Accomodation}/>
          <Route path="/Shop" Component={Cart}/>
          <Route path="/Furniture" Component={FurnitureService}/>
          <Route path='/Accomodation/moreinfo' Component={AccomodationInfo}/>
          <Route path='/AirportPickup' Component={AirportPickup}/>
          <Route path='/' Component={Home}/>
          <Route path='/*' Component={Invalid} />
        </Routes>

      </Router>

  


    </ChakraProvider>
    </ClerkProvider>
   
  )
}

export default App
